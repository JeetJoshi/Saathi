from django.shortcuts import render
import pandas as pd
import funx

s_c_1, s_c_2, s_c_3 = 0, 0, 0

s_statename = 0
s_season = 0
s_crop_1 = 0
s_crop_2 = 0
s_crop_3 = 0

a_statename = 0
a_season = 0
a_crop_1 = 0
a_crop_2 = 0
a_crop_3 = 0
a_loamy = 0
a_sandy = 0
a_black = 0
a_lateritic = 0
a_clay = 0
a_red = 0
a_sandy_loamy = 0
a_alluvial = 0
a_brown = 0
a_temperature = 0
a_rainfall = 0
a_pH = 0
a_water = 0
a_sand = 0
a_slit = 0
a_clayp = 0
a_organic = 0


# Create your views here.

def index(request):
    return render(request, 'ieeecrop/index.html')

def simple(request):
    return render(request, 'ieeecrop/simple.html')

def advanced(request):
    return render(request, 'ieeecrop/advanced.html')

def simplepredict(request):

    if request.method=="POST":
        global s_statename
        s_statename = request.POST['state']
        global s_season
        s_season = request.POST['season']
        global s_crop_1
        s_crop_1 = int(request.POST['crop1'])
        global s_crop_2
        s_crop_2 = int(request.POST['crop2'])
        global s_crop_3
        s_crop_3 = int(request.POST['crop3'])
        funx.p_predict(s_statename, s_season, s_crop_1, s_crop_2, s_crop_3)


    return render(request, 'ieeecrop/simplepredict.html')

def advancedpredict(request):

    if request.method == "POST":
        global a_statename
        a_statename = request.POST['state']
        global a_season
        a_season = request.POST['season']
        global a_crop_1
        a_crop_1 = int(request.POST['crop1'])
        global a_crop_2
        a_crop_2 = int(request.POST['crop2'])
        global a_crop_3
        a_crop_3 = int(request.POST['crop3'])
        global a_loamy
        a_loamy = int(request.POST['loamy'])
        global a_sandy
        a_sandy = int(request.POST['sandy'])
        global a_black
        a_black = int(request.POST['black'])
        global a_lateritic
        a_lateritic = int(request.POST['lateritic'])
        global a_clay
        a_clay = int(request.POST['clay'])
        global a_red
        a_red = int(request.POST['red'])
        global a_sandy_loamy
        a_sandy_loamy = int(request.POST['sandy-loamy'])
        global a_alluvial
        a_alluvial = int(request.POST['alluvial'])
        global a_brown
        a_brown = int(request.POST['brown'])
        global a_temperature
        a_temperature = float(request.POST['temperature'])
        global a_rainfall
        a_rainfall = float(request.POST['rainfall'])
        global a_pH
        a_pH = float(request.POST['pH'])
        global a_water
        a_water = float(request.POST['water'])
        global a_sand
        a_sand = float(request.POST['sand'])
        global a_slit
        a_slit = float(request.POST['slit'])
        global a_clayp
        a_clayp = float(request.POST['clayp'])
        global a_organic
        a_organic = float(request.POST['organic'])

        
        L = []
        L.append(a_statename)
        L.append(a_season)
        L.append(a_crop_1)
        L.append(a_crop_2)
        L.append(a_crop_3)
        L.append(a_temperature)
        L.append(a_rainfall)
        L.append(a_loamy)
        L.append(a_sandy)
        L.append(a_black)
        L.append(a_lateritic)
        L.append(a_clay)
        L.append(a_red)
        L.append(a_sandy_loamy)
        L.append(a_alluvial)
        L.append(a_brown)
        L.append(a_pH)
        L.append(a_water)
        L.append(a_sand)
        L.append(a_slit)
        L.append(a_clayp)
        L.append(a_organic)
        funx.p_predict_a(L[0],L[1],L[2],L[3],L[4],L[5],L[6],L[7],L[8],L[9],L[10],L[11],L[12],L[13],L[14],L[15],L[16],L[17],L[18],L[19],L[20],L[21])



    return render(request, 'ieeecrop/advancedpredict.html')


def simple_information(request):
    global s_c_1
    global s_c_2
    global s_c_3
    [s_c_1, s_c_2, s_c_3] = funx.p_predict(s_statename, s_season, s_crop_1, s_crop_2, s_crop_3)
    info = pd.read_csv('./var/www/mysite/Table.csv')

    #s_c_1 = crop_names[0]
    #s_c_2 = crop_names[1]
    #s_c_3 = crop_names[0]

    s_c_1_0 = info[s_c_1][0]
    s_c_1_1 = info[s_c_1][1]
    s_c_1_2 = info[s_c_1][2]
    s_c_1_3 = info[s_c_1][3]
    s_c_1_4 = info[s_c_1][4]
    s_c_1_5 = info[s_c_1][5]
    s_c_1_6 = info[s_c_1][6]
    s_c_1_7 = info[s_c_1][7]

    s_c_2_0 = info[s_c_2][0]
    s_c_2_1 = info[s_c_2][1] 
    s_c_2_2 = info[s_c_2][2]
    s_c_2_3 = info[s_c_2][3]
    s_c_2_4 = info[s_c_2][4]
    s_c_2_5 = info[s_c_2][5]
    s_c_2_6 = info[s_c_2][6]
    s_c_2_7 = info[s_c_2][7]
    
    s_c_3_0 = info[s_c_3][0]
    s_c_3_1 = info[s_c_3][1]
    s_c_3_2 = info[s_c_3][2]
    s_c_3_3 = info[s_c_3][3]
    s_c_3_4 = info[s_c_3][4]
    s_c_3_5 = info[s_c_3][5]
    s_c_3_6 = info[s_c_3][6]
    s_c_3_7 = info[s_c_3][7]

    context = {
        's_c_1': s_c_1,
        's_c_2': s_c_2,
        's_c_3': s_c_3,

        's_c_1_0': s_c_1_0,
        's_c_1_1': s_c_1_1,
        's_c_1_2': s_c_1_2,
        's_c_1_3': s_c_1_3,
        's_c_1_4': s_c_1_4,
        's_c_1_5': s_c_1_5,
        's_c_1_6': s_c_1_6,
        's_c_1_7': s_c_1_7,
    
        's_c_2_0': s_c_2_0,
        's_c_2_1': s_c_2_1,
        's_c_2_2': s_c_2_2,
        's_c_2_3': s_c_2_3,
        's_c_2_4': s_c_2_4,
        's_c_2_5': s_c_2_5,
        's_c_2_6': s_c_2_6,
        's_c_2_7': s_c_2_7,
        
        's_c_3_0': s_c_3_0,
        's_c_3_1': s_c_3_1,
        's_c_3_2': s_c_3_2,
        's_c_3_3': s_c_3_3,
        's_c_3_4': s_c_3_4,
        's_c_3_5': s_c_3_5,
        's_c_3_6': s_c_3_6,
        's_c_3_7': s_c_3_7,
    }
    crop_names = []

    return render(request, 'ieeecrop/simple_table.html', context)

def advance_information(request):
    global a_c_1
    global a_c_2
    global a_c_3
    [a_c_1, a_c_2, a_c_3] = funx.p_predict_a(a_statename, a_season, a_crop_1, a_crop_2, a_crop_3, a_temperature, a_rainfall, a_loamy, a_sandy, a_black, a_lateritic, a_clay, a_red, a_sandy_loamy, a_alluvial, a_brown, a_pH, a_water, a_sand, a_slit, a_clayp, a_organic)
    info = pd.read_csv('./var/www/mysite/Table.csv')

    #s_c_1 = crop_names[0]
    #s_c_2 = crop_names[1]
    #s_c_3 = crop_names[0]

    a_c_1_0 = info[a_c_1][0]
    a_c_1_1 = info[a_c_1][1]
    a_c_1_2 = info[a_c_1][2]
    a_c_1_3 = info[a_c_1][3]
    a_c_1_4 = info[a_c_1][4]
    a_c_1_5 = info[a_c_1][5]
    a_c_1_6 = info[a_c_1][6]
    a_c_1_7 = info[a_c_1][7]

    a_c_2_0 = info[a_c_2][0]
    a_c_2_1 = info[a_c_2][1] 
    a_c_2_2 = info[a_c_2][2]
    a_c_2_3 = info[a_c_2][3]
    a_c_2_4 = info[a_c_2][4]
    a_c_2_5 = info[a_c_2][5]
    a_c_2_6 = info[a_c_2][6]
    a_c_2_7 = info[a_c_2][7]
    
    a_c_3_0 = info[a_c_3][0]
    a_c_3_1 = info[a_c_3][1]
    a_c_3_2 = info[a_c_3][2]
    a_c_3_3 = info[a_c_3][3]
    a_c_3_4 = info[a_c_3][4]
    a_c_3_5 = info[a_c_3][5]
    a_c_3_6 = info[a_c_3][6]
    a_c_3_7 = info[a_c_3][7]

    context = {
        'a_c_1': a_c_1,
        'a_c_2': a_c_2,
        'a_c_3': a_c_3,

        'a_c_1_0': a_c_1_0,
        'a_c_1_1': a_c_1_1,
        'a_c_1_2': a_c_1_2,
        'a_c_1_3': a_c_1_3,
        'a_c_1_4': a_c_1_4,
        'a_c_1_5': a_c_1_5,
        'a_c_1_6': a_c_1_6,
        'a_c_1_7': a_c_1_7,
    
        'a_c_2_0': a_c_2_0,
        'a_c_2_1': a_c_2_1,
        'a_c_2_2': a_c_2_2,
        'a_c_2_3': a_c_2_3,
        'a_c_2_4': a_c_2_4,
        'a_c_2_5': a_c_2_5,
        'a_c_2_6': a_c_2_6,
        'a_c_2_7': a_c_2_7,
        
        'a_c_3_0': a_c_3_0,
        'a_c_3_1': a_c_3_1,
        'a_c_3_2': a_c_3_2,
        'a_c_3_3': a_c_3_3,
        'a_c_3_4': a_c_3_4,
        'a_c_3_5': a_c_3_5,
        'a_c_3_6': a_c_3_6,
        'a_c_3_7': a_c_3_7,
    }
    crop_names = []

    return render(request, 'ieeecrop/advance_table.html', context)

