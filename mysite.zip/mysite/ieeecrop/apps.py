from django.apps import AppConfig


class IeeecropConfig(AppConfig):
    name = 'ieeecrop'
