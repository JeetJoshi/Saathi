import h5py
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def reader():
	data = pd.read_csv('./var/www/mysite/Table.csv')
	return data

#Nacessary Functions.....
def ReLU(x):
    return x * (x > 0)
def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()
def sigmoid(x):
    return 1 / (1 + np.exp(-x))
def make_op(p):
    for i in range(len(p[0])):
        if p[0,i] > 0.002:
            pass
        else:
            p[0,i] = 0
    return(p)
def one_hot(a,lh):
    b = np.zeros((1, lh))
    b[0,a] = 1
    return b
def filter(p):
    for i in range(len(p[0])):
        if p[0,i] == 0.35:
            p[0,i] = 0
        else:
            pass            
    return(p)
def shorting(p):
    first = 0
    second = 0
    third = 0
    q = np.sort(p)
    q = q[0][::-1]
    for i in range(len(q)):
        if p[0][i] == q[0]:
           print('yey.....')
           first = i
        elif p[0][i] == q[1]:
            second = i
        elif p[0][i] == q[2]:
            third = i
    return first,second,third,q[0],q[1],q[2]
def temp_norm(mi1):
    mi1 = (mi1 - 14)/16
    return mi1

def rain_norm(mi2):
    mi2 = (mi2 - 18)/232
    return mi2

def pH_norm(mi3):
    mi3 = (mi3 - 5.05)/2.3
    return mi3
def water_norm(mi13):
    mi13 = (mi13-3)/8977
    return mi13
def texature_norm(mi14,mi15,mi16):
    mi14 = mi14/65
    mi15 = mi15/40
    mi16 = mi16/38
    return mi14,mi15,mi16
def oc_norm(mi17):
    mi17 = mi17/2.71
    return mi17
def combine(mi1,mi2,mi3,mi4,mi5,mi6,mi7,mi8,mi9,mi10,mi11,mi12,mi13,mi14,mi15,mi16,mi17):
    model_input = np.zeros((1,17))
    mi1 = temp_norm(mi1)
    mi2 = rain_norm(mi2)
    mi12 = pH_norm(mi12)
    mi13 = water_norm(mi13)
    mi14,mi15,mi16 = texature_norm(mi13,mi14,mi15)
    mi17 = oc_norm(mi17)
    model_input = np.array([[mi1,mi2,mi3,mi4,mi5,mi6,mi7,mi8,mi9,mi10,mi11,mi12,mi13,mi14,mi15,mi16,mi17]])
    return model_input




#Model.......
def model(t):
    file = h5py.File('./var/www/mysite/Selective.h5', 'r')
    weights0 = np.array(file['model_weights']['dense_3']['dense_3']['kernel:0'])
    weights1 = np.array(file['model_weights']['dense_4']['dense_4']['kernel:0'])
    weights2 = np.array(file['model_weights']['dense_5']['dense_5']['kernel:0'])
    bias0 = np.array(file['model_weights']['dense_3']['dense_3']['bias:0'])
    bias1 = np.array(file['model_weights']['dense_4']['dense_4']['bias:0'])
    bias2 = np.array(file['model_weights']['dense_5']['dense_5']['bias:0'])
    l1 = np.matmul(t,weights0) + bias0
    l1 = ReLU(l1)
    l2 = np.matmul(l1,weights1) + bias1
    l2 = ReLU(l2)
    l3 = np.matmul(l2,weights2) + bias2
    l3 = softmax(l3)
    return l3


#Model 0.......
def model0(t0):
    file0 = h5py.File('./var/www/mysite/Straight_model.h5', 'r')
    weights00 = np.array(file0['model_weights']['dense_3']['dense_3']['kernel:0'])
    weights01 = np.array(file0['model_weights']['dense_4']['dense_4']['kernel:0'])
    weights02 = np.array(file0['model_weights']['dense_5']['dense_5']['kernel:0'])
    bias00 = np.array(file0['model_weights']['dense_3']['dense_3']['bias:0'])
    bias01 = np.array(file0['model_weights']['dense_4']['dense_4']['bias:0'])
    bias02 = np.array(file0['model_weights']['dense_5']['dense_5']['bias:0'])
    l01 = np.matmul(t0,weights00) + bias00
    l01 = ReLU(l01)
    l02 = np.matmul(l01,weights01) + bias01
    l02 = ReLU(l02)
    l03 = np.matmul(l02,weights02) + bias02
    l03 = sigmoid(l03)
    return make_op(l03)


#Model 1......
def model1(t1):
    file1 = h5py.File('./var/www/mysite/recommender.h5', 'r')
    weights10 = np.array(file1['model_weights']['dense_12']['dense_12']['kernel:0'])
    weights11 = np.array(file1['model_weights']['dense_13']['dense_13']['kernel:0'])
    weights12 = np.array(file1['model_weights']['dense_14']['dense_14']['kernel:0'])
    bias10 = np.array(file1['model_weights']['dense_12']['dense_12']['bias:0'])
    bias11 = np.array(file1['model_weights']['dense_13']['dense_13']['bias:0'])
    bias12 = np.array(file1['model_weights']['dense_14']['dense_14']['bias:0'])
    l11 = np.matmul(t1,weights10) + bias10
    l11 = ReLU(l11)
    l12 = np.matmul(l11,weights11) + bias11
    l12 = ReLU(l12)
    l13 = np.matmul(l12,weights12) + bias12
    l13 = sigmoid(l13)
    return make_op(l13)


#Modela.......
def modela(ta):
    filea0 = h5py.File('./var/www/mysite/A_Selective.h5', 'r')
    weightsa0 = np.array(filea0['model_weights']['dense_6']['dense_6']['kernel:0'])
    weightsa1 = np.array(filea0['model_weights']['dense_7']['dense_7']['kernel:0'])
    weightsa2 = np.array(filea0['model_weights']['dense_8']['dense_8']['kernel:0'])
    biasa0 = np.array(filea0['model_weights']['dense_6']['dense_6']['bias:0'])
    biasa1 = np.array(filea0['model_weights']['dense_7']['dense_7']['bias:0'])
    biasa2 = np.array(filea0['model_weights']['dense_8']['dense_8']['bias:0'])
    la1 = np.matmul(ta,weightsa0) + biasa0
    la1 = ReLU(la1)
    la2 = np.matmul(la1,weightsa1) + biasa1
    la2 = ReLU(la2)
    la3 = np.matmul(la2,weightsa2) + biasa2
    la3 = softmax(la3)
    return(la3)




#Pediction
def p_predict(ip1,ip2,c1,c2,c3):
    key2 = 0
    key = 0
    model_input = np.zeros((1,12))

    data_rs = pd.read_csv('./var/www/mysite/Rain_Soil.csv')
    X = np.array(data_rs.drop(['states'],axis= 1))
    data_rs = np.array(data_rs).T
    data_t = pd.read_csv('./var/www/mysite/Temperature.csv')
    data_t = np.array(data_t.drop(['states'],axis= 1))
    
    for i in range(len(data_rs[0])):
        if data_rs[0][i] == ip1:
            key = i
    model_input[0][1:12] = X[key]
    data_t = pd.read_csv('./var/www/mysite/Temperature.csv')
    data_t = np.array(data_t.drop(['states'],axis= 1))
    if ip2 == 'Winter':
        key2 = 0
    elif ip2 == 'Summer':
        key2 = 1
    else:
        key2 = 2
    model_input[0][0] = data_t[key][key2]

    #Model .........
    op = model(model_input)
    op = op*0.3

    #Model 0........
    op0 = model0(one_hot(np.array([key]),24)) * 0.35


    #Model 1.............
    op1_1 = model1(one_hot(np.array([c1]),40)) * 0.7
    op1_2 = model1(one_hot(np.array([c2]),40)) * 0.15
    op1_3 = model1(one_hot(np.array([c3]),40)) * 0.15
    op1 = (op1_1 + op1_2 + op1_3) * 0.35

    #Final Op
    final = op + op0 + op1 



    
    name= np.array(['Rice','Wheat','Cotton','Jute','Sugarcane','Tea ','Coffee','Spices','Potatos','tomatos','onion','cauliflower','Cabbage','Bean','Cucumber','Garlic','LadyFinger','Radish','Carrot','Corn','Red Chilli','Green Chilli','Spinach','Fenugreek','Anola/Amla','Banana','Mango','Guava','Citrus','Papaya','gram','mong','tur','urad','soyabean','peas','rubber','mustard','jowar','bajra'])
    final = filter(final)
    a1,a2,a3,v1,v2,v3 = shorting(final)
    final_names = []
    final_names.append([name[a1],name[a2],name[a3]])
    final_names = final_names[0]


    # Graph..............
    import matplotlib.pyplot as plt
    #f, ax = plt.subplots(figsize=(18,8))
    #values = np.array(final[0])
    plt.bar(final_names, [v1, v2, v3])
    plt.savefig('./var/www/mysite/static/simple.jpg')
    plt.close()
    return final_names




def p_predict_a(ip1,ip2,c1,c2,c3,mi1,mi2,mi3,mi4,mi5,mi6,mi7,mi8,mi9,mi10,mi11,mi12,mi13,mi14,mi15,mi16,mi17):
    model_input = combine(mi1,mi2,mi3,mi4,mi5,mi6,mi7,mi8,mi9,mi10,mi11,mi12,mi13,mi14,mi15,mi16,mi17)
    key = 0
    data_rs = pd.read_csv('./var/www/mysite/Rain_Soil.csv')
    data_rs = np.array(data_rs).T
    for i in range(len(data_rs[0])):
        if data_rs[0][i] == ip1:
            key = i
    #Model .........
    op = modela(model_input)
    op = op*0.3

    #Model 0........
    op0 = model0(one_hot(np.array([key]),24)) * 0.35


    #Model 1.............
    op1_1 = model1(one_hot(np.array([c1]),40)) * 0.7
    op1_2 = model1(one_hot(np.array([c2]),40)) * 0.15
    op1_3 = model1(one_hot(np.array([c3]),40)) * 0.15
    op1 = (op1_1 + op1_2 + op1_3) * 0.35

    #Final Op
    final = op + op0 + op1 



    
    name= np.array(['Rice','Wheat','Cotton','Jute','Sugarcane','Tea ','Coffee','Spices','Potatos','tomatos','onion','cauliflower','Cabbage','Bean','Cucumber','Garlic','LadyFinger','Radish','Carrot','Corn','Red Chilli','Green Chilli','Spinach','Fenugreek','Anola/Amla','Banana','Mango','Guava','Citrus','Papaya','gram','mong','tur','urad','soyabean','peas','rubber','mustard','jowar','bajra'])
    final = filter(final)
    a1,a2,a3,v1,v2,v3 = shorting(final)
    final_names = []
    final_names.append([name[a1],name[a2],name[a3]])
    final_names = final_names[0]


    # Graph..............
    import matplotlib.pyplot as plt
    plt.bar(final_names, [v1, v2, v3])
    plt.savefig('./var/www/mysite/static/advanced.jpg')
    plt.close()
    return final_names
